(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4843],{1028:(e,i,a)=>{"use strict";a.d(i,{default:()=>c});var s=a(5155),t=a(2115),r=a(7529);function n({name:e,email:i}){let a=e?.trim()||"Staff Admin",t=(e?.trim()||i||"S").charAt(0).toUpperCase();return(0,s.jsxs)("div",{className:"admin-account",style:{display:"flex",alignItems:"center",gap:12,minWidth:0},children:[(0,s.jsx)("span",{className:"admin-avatar","aria-hidden":"true",style:{display:"grid",placeItems:"center",width:42,height:42,flexShrink:0,borderRadius:"50%",background:"#f5b82e",color:"#10121b",fontWeight:800},children:t}),(0,s.jsxs)("span",{style:{display:"flex",flexDirection:"column",gap:3,minWidth:0},children:[(0,s.jsx)("strong",{style:{color:"#f5f6fa",fontSize:14,overflowWrap:"anywhere"},children:a}),(0,s.jsx)("small",{style:{color:"#a5acc1",fontSize:12,overflowWrap:"anywhere"},children:i})]})]})}let o={SUPER_ADMIN:["staff:read","staff:manage","rewards:manage","predictions:manage","trivia:manage","polls:manage","fanrooms:manage","content:moderate","fans:support","players:manage","kyc:manage"],OPERATIONS:["rewards:manage","predictions:manage","kyc:manage"],CONTENT_MODERATION:["trivia:manage","polls:manage","content:moderate"],SUPPORT:["fans:support"]};function c({permission:e,children:i}){let[a,d]=(0,t.useState)(!1),[l,p]=(0,t.useState)(!0),[m,u]=(0,t.useState)(null);return((0,t.useEffect)(()=>{let i=!0;return async function(){try{let a=await (0,r.n)("/api/admin/me",{cache:"no-store"}),s=await a.json().catch(()=>({}));if(!i)return;if(403===a.status&&"PASSWORD_CHANGE_REQUIRED"===s.code)return void window.location.replace("/sf-vault-k8m42x/change-password/");if(401===a.status||!a.ok)return void window.location.replace("/sf-vault-k8m42x/login/");let t=s.admin?.staffRole;if(!t||!o[t]?.includes(e))return void window.location.replace("/sf-vault-k8m42x/dashboard/");u({name:s.admin?.name??null,email:s.admin?.email??""}),d(!0)}catch{i&&window.location.replace("/sf-vault-k8m42x/login/")}finally{i&&p(!1)}}(),()=>{i=!1}},[e]),l||!a)?(0,s.jsx)("main",{style:{minHeight:"100vh",display:"grid",placeItems:"center",background:"#10121b",color:"#f5b82e",fontFamily:"Lato, Arial, sans-serif"},children:"Verifying staff access..."}):(0,s.jsxs)(s.Fragment,{children:[m&&(0,s.jsx)("div",{style:{display:"flex",justifyContent:"flex-end",padding:"16px 28px",background:"#10121b",borderBottom:"1px solid #303447"},children:(0,s.jsx)(n,{name:m.name,email:m.email})}),i]})}},5227:(e,i,a)=>{"use strict";a.d(i,{default:()=>c});var s=a(5155),t=a(7529),r=a(2115);let n=["ALL","PENDING","APPROVED","REJECTED"];function o(e){if(!e)return"—";let i=new Date(e);return Number.isNaN(i.getTime())?e:i.toLocaleString()}function c(){let[e,i]=(0,r.useState)([]),[a,c]=(0,r.useState)("PENDING"),[d,l]=(0,r.useState)({}),[p,m]=(0,r.useState)(!0),[u,b]=(0,r.useState)(null),[x,f]=(0,r.useState)(""),[y,h]=(0,r.useState)(""),[g,k]=(0,r.useState)(null),j=(0,r.useCallback)(async()=>{m(!0),f("");try{let e="ALL"===a?"":`?status=${a}`,s=await (0,t.n)(`/api/admin/kyc${e}`,{cache:"no-store"}),r=await s.json();if(!s.ok)throw Error(r.error||"Unable to load KYC submissions.");i(r.submissions??[])}catch(e){f(e instanceof Error?e.message:"Unable to load KYC submissions.")}finally{m(!1)}},[a]);async function w(e,i){f(""),h("");let a=d[e]?.trim()??"";if("REJECTED"===i&&!a)return void f("Enter a rejection reason before rejecting this submission.");b(e);try{let s=await (0,t.n)("/api/admin/kyc",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({submissionId:e,decision:i,rejectionReason:"REJECTED"===i?a:void 0})}),r=await s.json();if(!s.ok)throw Error(r.error||"Unable to review this submission.");k(null),h("APPROVED"===i?`KYC approved. ${r.progressionPointsAwarded??0} progression points awarded.`:"KYC submission rejected."),await j()}catch(e){f(e instanceof Error?e.message:"Unable to review this submission.")}finally{b(null)}}return(0,r.useEffect)(()=>{j()},[j]),(0,s.jsxs)("section",{className:"kyc-management",children:[(0,s.jsxs)("div",{className:"kyc-toolbar",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("h2",{children:"Submissions"}),(0,s.jsx)("p",{children:"Personal KYC details are visible only to authorised reviewers."})]}),(0,s.jsx)("button",{type:"button",className:"kyc-refresh",onClick:()=>void j(),disabled:p||null!==u,children:"Refresh"})]}),(0,s.jsx)("div",{className:"kyc-filters","aria-label":"Filter submissions",children:n.map(e=>(0,s.jsx)("button",{type:"button",className:a===e?"active":"",onClick:()=>c(e),disabled:p||null!==u,children:"ALL"===e?"All":e},e))}),x&&(0,s.jsx)("p",{className:"kyc-alert error",role:"alert",children:x}),y&&(0,s.jsx)("p",{className:"kyc-alert success",role:"status",children:y}),p?(0,s.jsx)("p",{className:"kyc-empty",children:"Loading submissions…"}):0===e.length?(0,s.jsx)("p",{className:"kyc-empty",children:"No submissions found for this filter."}):(0,s.jsx)("div",{className:"kyc-list",children:e.map(e=>(0,s.jsxs)("article",{className:"kyc-card",children:[(0,s.jsxs)("div",{className:"kyc-card-top",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("p",{className:"kyc-account-name",children:e.user.name||e.user.username||"Name not provided"}),(0,s.jsxs)("p",{className:"kyc-submission-id",children:["Submission #",e.id," \xb7 Fan #",e.userId]}),(0,s.jsx)("span",{className:`kyc-status ${e.status.toLowerCase()}`,children:e.status})]}),(0,s.jsxs)("div",{className:"kyc-submitted",children:[(0,s.jsx)("span",{children:"Submitted"}),(0,s.jsx)("strong",{children:o(e.createdAt)})]})]}),(0,s.jsxs)("dl",{className:"kyc-details",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("dt",{children:"WhatsApp number"}),(0,s.jsx)("dd",{children:e.whatsappNumber})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("dt",{children:"Country"}),(0,s.jsx)("dd",{children:e.country})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("dt",{children:"State"}),(0,s.jsx)("dd",{children:e.state})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("dt",{children:"Sex"}),(0,s.jsx)("dd",{children:e.sex})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("dt",{children:"Date of birth"}),(0,s.jsx)("dd",{children:e.dateOfBirth})]})]}),"REJECTED"===e.status&&e.rejectionReason&&(0,s.jsxs)("p",{className:"kyc-reason",children:[(0,s.jsx)("strong",{children:"Rejection reason:"})," ",e.rejectionReason]}),"PENDING"!==e.status&&(0,s.jsxs)("p",{className:"kyc-reviewed",children:["Reviewed ",o(e.reviewedAt)]}),"PENDING"===e.status&&(0,s.jsxs)("div",{className:"kyc-review-actions",children:[(0,s.jsxs)("label",{children:["Rejection reason",(0,s.jsx)("textarea",{value:d[e.id]??"",onChange:i=>l(a=>({...a,[e.id]:i.target.value})),placeholder:"Required only when rejecting",maxLength:1e3,rows:2,disabled:u===e.id})]}),(0,s.jsxs)("div",{className:"kyc-buttons",children:[(0,s.jsx)("button",{type:"button",className:"kyc-reject",onClick:()=>{(f(""),h(""),d[e.id]?.trim())?k({submissionId:e.id,decision:"REJECTED"}):f("Enter a rejection reason before rejecting this submission.")},disabled:null!==u,children:u===e.id?"Reviewing…":"Reject"}),(0,s.jsx)("button",{type:"button",className:"kyc-approve",onClick:()=>{f(""),h(""),k({submissionId:e.id,decision:"APPROVED"})},disabled:null!==u,children:u===e.id?"Reviewing…":"Approve \xb7 +40"})]})]})]},e.id))}),g&&(()=>{let i=e.find(e=>e.id===g.submissionId);if(!i)return null;let a="APPROVED"===g.decision,t=i.user.name||i.user.username||"this fan";return(0,s.jsx)("div",{className:"kyc-modal-overlay",children:(0,s.jsxs)("section",{className:"kyc-confirm-modal",role:"dialog","aria-modal":"true","aria-labelledby":"kyc-confirm-title",children:[(0,s.jsx)("div",{className:"kyc-modal-icon",children:a?"✓":"!"}),(0,s.jsx)("h2",{id:"kyc-confirm-title",children:a?"Approve KYC submission?":"Reject KYC submission?"}),(0,s.jsx)("p",{className:"kyc-modal-fan",children:t}),(0,s.jsx)("p",{className:"kyc-modal-description",children:a?"You are about to approve this fan's KYC details. This will award 40 progression points if the KYC reward has not already been issued.":"You are about to reject this fan's KYC submission. The rejection reason you provided will be recorded."}),(0,s.jsxs)("div",{className:"kyc-modal-actions",children:[(0,s.jsx)("button",{type:"button",className:"kyc-modal-cancel",onClick:()=>k(null),disabled:null!==u,children:"Cancel"}),(0,s.jsx)("button",{type:"button",className:a?"kyc-modal-confirm":"kyc-modal-reject",onClick:()=>void w(g.submissionId,g.decision),disabled:null!==u,children:u===g.submissionId?"Processing…":a?"Confirm Approval":"Confirm Rejection"})]})]})})})(),(0,s.jsx)("style",{children:`
        .kyc-modal-overlay {
          position: fixed;
          inset: 0;
          z-index: 10000;
          display: grid;
          place-items: center;
          padding: 20px;
          background: rgba(0, 0, 0, .75);
          backdrop-filter: blur(4px);
        }
        .kyc-confirm-modal {
          width: 100%;
          max-width: 440px;
          box-sizing: border-box;
          padding: 30px;
          border: 1px solid #353b4d;
          border-radius: 18px;
          background: #151925;
          color: #f7f8fc;
          text-align: center;
          box-shadow: 0 24px 80px rgba(0, 0, 0, .45);
        }
        .kyc-modal-icon {
          display: grid;
          place-items: center;
          width: 48px;
          height: 48px;
          margin: 0 auto 18px;
          border-radius: 50%;
          background: #3c3219;
          color: #f5b82e;
          font-size: 25px;
          font-weight: 800;
        }
        .kyc-confirm-modal h2 {
          margin: 0 0 12px;
          font-size: 20px;
        }
        .kyc-modal-fan {
          margin: 0 0 10px;
          color: #f5b82e;
          font-size: 16px;
          font-weight: 800;
        }
        .kyc-modal-description {
          margin: 0;
          color: #a3a9bd;
          font-size: 13px;
          line-height: 1.7;
        }
        .kyc-modal-actions {
          display: flex;
          justify-content: center;
          gap: 10px;
          margin-top: 26px;
        }
        .kyc-modal-actions button {
          min-height: 42px;
          padding: 10px 16px;
          border: 1px solid #3a3e4e;
          border-radius: 9px;
          font: inherit;
          font-weight: 700;
          cursor: pointer;
        }
        .kyc-modal-cancel {
          background: #191d2a;
          color: #f7f8fc;
        }
        .kyc-modal-confirm {
          border-color: #f5b82e !important;
          background: #f5b82e;
          color: #10121b;
        }
        .kyc-modal-reject {
          border-color: #a44354 !important;
          background: #a44354;
          color: white;
        }
        .kyc-modal-actions button:disabled {
          opacity: .55;
          cursor: not-allowed;
        }
        .kyc-management { color: #f7f8fc; }
        .kyc-toolbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          margin-bottom: 20px;
        }
        .kyc-toolbar h2 { margin: 0 0 6px; font-size: 21px; }
        .kyc-toolbar p { margin: 0; color: #a3a9bd; font-size: 13px; }
        .kyc-refresh, .kyc-filters button, .kyc-buttons button {
          border: 1px solid #3a3e4e;
          border-radius: 9px;
          padding: 10px 14px;
          color: #f7f8fc;
          background: #191d2a;
          font: inherit;
          cursor: pointer;
        }
        .kyc-refresh:disabled, .kyc-filters button:disabled,
        .kyc-buttons button:disabled { opacity: .55; cursor: not-allowed; }
        .kyc-filters {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-bottom: 22px;
        }
        .kyc-filters button.active {
          background: #f5b82e;
          border-color: #f5b82e;
          color: #10121b;
          font-weight: 800;
        }
        .kyc-alert {
          padding: 12px 14px;
          border-radius: 9px;
          line-height: 1.5;
        }
        .kyc-alert.error { background: #3a2027; color: #ffb7c2; }
        .kyc-alert.success { background: #183629; color: #9ce8b9; }
        .kyc-empty {
          padding: 28px;
          border: 1px solid #292d3d;
          border-radius: 12px;
          color: #a3a9bd;
          text-align: center;
        }
        .kyc-list { display: grid; gap: 16px; }
        .kyc-card {
          padding: 22px;
          border: 1px solid #292d3d;
          border-radius: 14px;
          background: #151925;
        }
        .kyc-card-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
          margin-bottom: 20px;
        }
        .kyc-submission-id {
          margin: 0 0 10px;
          color: #a3a9bd;
          font-size: 12px;
        }
        .kyc-status {
          display: inline-block;
          padding: 5px 9px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 800;
          letter-spacing: .5px;
        }
        .kyc-status.pending { background: #3c3219; color: #f5d47d; }
        .kyc-status.approved { background: #183629; color: #9ce8b9; }
        .kyc-status.rejected { background: #3a2027; color: #ffb7c2; }
        .kyc-submitted {
          display: grid;
          gap: 5px;
          text-align: right;
          color: #a3a9bd;
          font-size: 12px;
        }
        .kyc-submitted strong { color: #f7f8fc; font-weight: 600; }
        .kyc-details {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 18px;
          margin: 0;
        }
        .kyc-details div { min-width: 0; }
        .kyc-details dt {
          margin-bottom: 6px;
          color: #8e95aa;
          font-size: 12px;
        }
        .kyc-details dd {
          margin: 0;
          overflow-wrap: anywhere;
          color: #f7f8fc;
          font-size: 14px;
        }
        .kyc-reason, .kyc-reviewed {
          margin: 18px 0 0;
          color: #a3a9bd;
          font-size: 13px;
          line-height: 1.6;
        }
        .kyc-review-actions {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          align-items: end;
          gap: 16px;
          margin-top: 22px;
          padding-top: 18px;
          border-top: 1px solid #292d3d;
        }
        .kyc-review-actions label {
          display: grid;
          gap: 8px;
          color: #a3a9bd;
          font-size: 12px;
        }
        .kyc-review-actions textarea {
          width: 100%;
          box-sizing: border-box;
          resize: vertical;
          border: 1px solid #3a3e4e;
          border-radius: 8px;
          padding: 10px;
          background: #10121b;
          color: #f7f8fc;
          font: inherit;
        }
        .kyc-buttons { display: flex; gap: 8px; }
        .kyc-buttons .kyc-reject {
          border-color: #7a3845;
          color: #ffb7c2;
        }
        .kyc-buttons .kyc-approve {
          border-color: #f5b82e;
          background: #f5b82e;
          color: #10121b;
          font-weight: 800;
        }
        @media (max-width: 760px) {
          .kyc-details { grid-template-columns: repeat(2, minmax(0, 1fr)); }
          .kyc-review-actions { grid-template-columns: 1fr; }
          .kyc-buttons { justify-content: flex-end; }
        }
        @media (max-width: 480px) {
          .kyc-card { padding: 16px; }
          .kyc-card-top { flex-direction: column; }
          .kyc-submitted { text-align: left; }
          .kyc-details { grid-template-columns: 1fr; }
          .kyc-buttons { flex-direction: column-reverse; }
        }
      `})]})}},7529:(e,i,a)=>{"use strict";a.d(i,{n:()=>t});let s="https://api.sportyfanz.com".replace(/\/+$/,"")??0;function t(e,i={}){return fetch(function(e){if(/^https?:\/\//i.test(e))return e;let i=e.startsWith("/")?e:`/${e}`;return s?`${s}${i}`:i}(e),{...i,credentials:i.credentials??"include"})}},8731:(e,i,a)=>{Promise.resolve().then(a.bind(a,5227)),Promise.resolve().then(a.bind(a,1028))}},e=>{e.O(0,[8441,3794,7358],()=>e(e.s=8731)),_N_E=e.O()}]);