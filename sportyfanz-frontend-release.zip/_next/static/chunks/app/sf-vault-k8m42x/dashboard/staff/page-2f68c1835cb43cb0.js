(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9056],{1028:(e,a,t)=>{"use strict";t.d(a,{default:()=>l});var s=t(5155),r=t(2115),n=t(7529);function i({name:e,email:a}){let t=e?.trim()||"Staff Admin",r=(e?.trim()||a||"S").charAt(0).toUpperCase();return(0,s.jsxs)("div",{className:"admin-account",style:{display:"flex",alignItems:"center",gap:12,minWidth:0},children:[(0,s.jsx)("span",{className:"admin-avatar","aria-hidden":"true",style:{display:"grid",placeItems:"center",width:42,height:42,flexShrink:0,borderRadius:"50%",background:"#f5b82e",color:"#10121b",fontWeight:800},children:r}),(0,s.jsxs)("span",{style:{display:"flex",flexDirection:"column",gap:3,minWidth:0},children:[(0,s.jsx)("strong",{style:{color:"#f5f6fa",fontSize:14,overflowWrap:"anywhere"},children:t}),(0,s.jsx)("small",{style:{color:"#a5acc1",fontSize:12,overflowWrap:"anywhere"},children:a})]})]})}let o={SUPER_ADMIN:["staff:read","staff:manage","rewards:manage","predictions:manage","trivia:manage","polls:manage","fanrooms:manage","content:moderate","fans:support","players:manage","kyc:manage"],OPERATIONS:["rewards:manage","predictions:manage","kyc:manage"],CONTENT_MODERATION:["trivia:manage","polls:manage","content:moderate"],SUPPORT:["fans:support"]};function l({permission:e,children:a}){let[t,d]=(0,r.useState)(!1),[f,c]=(0,r.useState)(!0),[p,h]=(0,r.useState)(null);return((0,r.useEffect)(()=>{let a=!0;return async function(){try{let t=await (0,n.n)("/api/admin/me",{cache:"no-store"}),s=await t.json().catch(()=>({}));if(!a)return;if(403===t.status&&"PASSWORD_CHANGE_REQUIRED"===s.code)return void window.location.replace("/sf-vault-k8m42x/change-password/");if(401===t.status||!t.ok)return void window.location.replace("/sf-vault-k8m42x/login/");let r=s.admin?.staffRole;if(!r||!o[r]?.includes(e))return void window.location.replace("/sf-vault-k8m42x/dashboard/");h({name:s.admin?.name??null,email:s.admin?.email??""}),d(!0)}catch{a&&window.location.replace("/sf-vault-k8m42x/login/")}finally{a&&c(!1)}}(),()=>{a=!1}},[e]),f||!t)?(0,s.jsx)("main",{style:{minHeight:"100vh",display:"grid",placeItems:"center",background:"#10121b",color:"#f5b82e",fontFamily:"Lato, Arial, sans-serif"},children:"Verifying staff access..."}):(0,s.jsxs)(s.Fragment,{children:[p&&(0,s.jsx)("div",{style:{display:"flex",justifyContent:"flex-end",padding:"16px 28px",background:"#10121b",borderBottom:"1px solid #303447"},children:(0,s.jsx)(i,{name:p.name,email:p.email})}),a]})}},2443:(e,a,t)=>{"use strict";t.d(a,{default:()=>i});var s=t(5155),r=t(7529),n=t(2115);function i(){let[e,a]=(0,n.useState)(""),[t,i]=(0,n.useState)(""),[o,l]=(0,n.useState)(!1),[d,f]=(0,n.useState)(""),[c,p]=(0,n.useState)(""),[h,u]=(0,n.useState)(null),[x,m]=(0,n.useState)([]),[g,b]=(0,n.useState)(!0),[j,w]=(0,n.useState)(""),[y,v]=(0,n.useState)(null),[S,k]=(0,n.useState)("SUPPORT"),[N,E]=(0,n.useState)(null),[C,T]=(0,n.useState)(null),[O,P]=(0,n.useState)(""),[A,R]=(0,n.useState)("");async function z(s){if(s.preventDefault(),f(""),p(""),u(null),e.trim().length<2)return void f("Enter the staff member's full name.");if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t.trim()))return void f("Enter a valid work email address.");l(!0);try{let s=await (0,r.n)("/api/admin/staff",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:e.trim(),email:t.trim().toLowerCase(),staffRole:S})}),n=await s.json();if(!s.ok)throw Error(n.error||"Unable to create staff account.");u(n.staff),p(n.message||(n.invitationEmailSent?"Staff account created. An invitation email has been sent.":"Staff account created, but the invitation email was not sent.")),a(""),i(""),k("SUPPORT"),await U()}catch(e){f(e instanceof Error?e.message:"Something went wrong. Please try again.")}finally{l(!1)}}async function U(){b(!0),w("");try{let e=await (0,r.n)("/api/admin/staff",{cache:"no-store"}),a=await e.json();if(!e.ok)throw Error(a.error||"Unable to load staff accounts.");m(a.staff??[])}catch(e){w(e instanceof Error?e.message:"Unable to load staff accounts.")}finally{b(!1)}}async function I(e,a){E(e),w("");try{let t=await (0,r.n)(`/api/admin/staff/${e}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({staffRole:a})}),s=await t.json();if(!t.ok)throw Error(s.error||"Unable to update staff role.");await U()}catch(e){w(e instanceof Error?e.message:"Unable to update staff role.")}finally{E(null)}}async function D(e){if("ACTIVE"!==e.status)return;let a=e.mustChangePassword?"resend-invitation":"reset-password";if(window.confirm(e.mustChangePassword?`Send a new invitation to ${e.email}? The previous invitation link will stop working.`:`Send a password reset link to ${e.email}?`)){T(e.id),P(""),R("");try{let t=await (0,r.n)(`/api/admin/staff/${e.id}/${a}`,{method:"POST"}),s=await t.json().catch(()=>({}));if(!t.ok)throw Error(s.error||"Unable to send the staff access email.");P(s.message||"Staff access email sent successfully.")}catch(e){R(e instanceof Error?e.message:"Unable to send the staff access email.")}finally{T(null)}}}async function _(e,a){v(e),w("");try{let t=await (0,r.n)(`/api/admin/staff/${e}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:a})}),s=await t.json();if(!t.ok)throw Error(s.error||"Unable to update staff status.");await U()}catch(e){w(e instanceof Error?e.message:"Unable to update staff status.")}finally{v(null)}}return(0,n.useEffect)(()=>{let e=!1;return async function(){w("");try{let a=await (0,r.n)("/api/admin/staff",{cache:"no-store"}),t=await a.json();if(!a.ok)throw Error(t.error||"Unable to load staff accounts.");e||m(t.staff??[])}catch(a){e||w(a instanceof Error?a.message:"Unable to load staff accounts.")}finally{e||b(!1)}}(),()=>{e=!0}},[]),(0,s.jsxs)("div",{className:"staff-workspace",children:[(0,s.jsxs)("section",{className:"staff-panel",children:[(0,s.jsxs)("div",{className:"staff-panel-heading",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{className:"staff-icon",children:"＋"}),(0,s.jsx)("h2",{children:"Create a staff account"}),(0,s.jsx)("p",{children:"Only authorised administrators can create internal staff accounts."})]}),(0,s.jsx)("span",{className:"staff-access-badge",children:"ADMIN ONLY"})]}),(0,s.jsxs)("form",{onSubmit:z,className:"staff-form",children:[(0,s.jsxs)("label",{children:["Full name",(0,s.jsx)("input",{value:e,onChange:e=>a(e.target.value),placeholder:"Enter staff member's name",autoComplete:"name",maxLength:100,required:!0})]}),(0,s.jsxs)("label",{children:["Work email",(0,s.jsx)("input",{type:"email",value:t,onChange:e=>i(e.target.value),placeholder:"staff@company.com",autoComplete:"email",maxLength:254,required:!0})]}),(0,s.jsxs)("label",{children:["Staff role",(0,s.jsxs)("select",{value:S,onChange:e=>k(e.target.value),required:!0,children:[(0,s.jsx)("option",{value:"SUPPORT",children:"Support"}),(0,s.jsx)("option",{value:"OPERATIONS",children:"Operations"}),(0,s.jsx)("option",{value:"CONTENT_MODERATION",children:"Content Moderation"}),(0,s.jsx)("option",{value:"SUPER_ADMIN",children:"Super Admin"})]})]}),(0,s.jsxs)("div",{className:"staff-form-note",children:[(0,s.jsx)("strong",{children:"Security notice"}),(0,s.jsx)("p",{children:"A unique staff username will be generated. The staff member will receive a secure email invitation to set their password. The invitation expires after one hour."})]}),d&&(0,s.jsx)("div",{className:"staff-alert staff-alert-error",role:"alert",children:d}),c&&(0,s.jsx)("div",{className:"staff-alert staff-alert-success",role:"status",children:c}),(0,s.jsx)("button",{className:"staff-primary-button",disabled:o,children:o?"Creating account...":"＋ Create staff account"})]})]}),h&&(0,s.jsxs)("section",{className:"staff-panel staff-credentials-panel",children:[(0,s.jsxs)("div",{className:"staff-panel-heading",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{className:"staff-icon",children:"✓"}),(0,s.jsx)("h2",{children:"Staff account created"}),(0,s.jsx)("p",{children:"Password setup is handled through a secure email invitation."})]}),(0,s.jsx)("span",{className:"staff-access-badge",children:"CREATED"})]}),(0,s.jsxs)("div",{className:"staff-created-details",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{children:"Staff member"}),(0,s.jsx)("strong",{children:h.name})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{children:"Work email"}),(0,s.jsx)("strong",{children:h.email})]}),(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{children:"Username"}),(0,s.jsx)("strong",{children:h.username})]})]}),(0,s.jsxs)("div",{className:"staff-form-note",children:[(0,s.jsx)("strong",{children:"Next step"}),(0,s.jsx)("p",{children:"The staff member should check their work email for a password setup invitation. If delivery fails, use Resend Invitation from the staff directory."})]}),(0,s.jsx)("a",{className:"staff-login-link",href:"/sf-vault-k8m42x/login/",children:"Open private staff login"})]}),(0,s.jsxs)("section",{className:"staff-panel",children:[(0,s.jsx)("div",{className:"staff-panel-heading",children:(0,s.jsxs)("div",{children:[(0,s.jsx)("span",{className:"staff-icon",children:"♙"}),(0,s.jsx)("h2",{children:"Staff directory"}),(0,s.jsx)("p",{children:"Staff listing and account-status controls will be connected to the protected staff API next."})]})}),(0,s.jsxs)("section",{className:"staff-directory",children:[(0,s.jsxs)("div",{className:"staff-directory-heading",children:[(0,s.jsxs)("div",{children:[(0,s.jsx)("h2",{children:"Staff Directory"}),(0,s.jsx)("p",{children:"Manage staff accounts and authorised access."})]}),(0,s.jsx)("button",{type:"button",onClick:()=>void U(),children:"Refresh"})]}),j&&(0,s.jsx)("p",{role:"alert",className:"staff-error",children:j}),O&&(0,s.jsx)("p",{role:"status",className:"staff-alert staff-alert-success",children:O}),A&&(0,s.jsx)("p",{role:"alert",className:"staff-alert staff-alert-error",children:A}),g?(0,s.jsx)("p",{children:"Loading staff accounts..."}):0===x.length?(0,s.jsx)("p",{children:"No staff accounts found."}):(0,s.jsx)("div",{className:"staff-table-wrap",children:(0,s.jsxs)("table",{className:"staff-table",children:[(0,s.jsx)("thead",{children:(0,s.jsxs)("tr",{children:[(0,s.jsx)("th",{children:"Staff member"}),(0,s.jsx)("th",{children:"Username"}),(0,s.jsx)("th",{children:"Role"}),(0,s.jsx)("th",{children:"Status"}),(0,s.jsx)("th",{children:"Last login"}),(0,s.jsx)("th",{children:"Access"})]})}),(0,s.jsx)("tbody",{children:x.map(e=>(0,s.jsxs)("tr",{children:[(0,s.jsxs)("td",{children:[(0,s.jsx)("strong",{children:e.name}),(0,s.jsx)("small",{children:e.email})]}),(0,s.jsx)("td",{children:e.username}),(0,s.jsxs)("td",{children:[(0,s.jsxs)("select",{"aria-label":`Role for ${e.name}`,value:e.staffRole,disabled:N===e.id||y===e.id,onChange:a=>void I(e.id,a.target.value),children:[(0,s.jsx)("option",{value:"SUPER_ADMIN",children:"Super Admin"}),(0,s.jsx)("option",{value:"OPERATIONS",children:"Operations"}),(0,s.jsx)("option",{value:"CONTENT_MODERATION",children:"Content Moderation"}),(0,s.jsx)("option",{value:"SUPPORT",children:"Support"})]}),N===e.id&&(0,s.jsx)("small",{children:"Saving role…"})]}),(0,s.jsx)("td",{children:(0,s.jsx)("span",{className:`staff-status staff-status-${e.status.toLowerCase()}`,children:e.status})}),(0,s.jsx)("td",{children:e.lastLoginAt?new Date(e.lastLoginAt).toLocaleString():"Never"}),(0,s.jsxs)("td",{children:["DELETED"!==e.status&&(0,s.jsx)("button",{type:"button",disabled:y===e.id,onClick:()=>void _(e.id,"ACTIVE"===e.status?"SUSPENDED":"ACTIVE"),children:y===e.id?"Updating...":"ACTIVE"===e.status?"Suspend":"Activate"}),"ACTIVE"===e.status&&(0,s.jsx)("button",{type:"button",disabled:null!==C||y===e.id||N===e.id,onClick:()=>void D(e),style:{marginLeft:8},children:C===e.id?"Sending...":e.mustChangePassword?"Resend Invitation":"Reset Password"}),e.mustChangePassword&&(0,s.jsx)("small",{children:" Password setup pending"})]})]},e.id))})]})})]})]}),(0,s.jsx)("style",{children:`
        .staff-workspace {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 22px;
          align-items: start;
        }
        .staff-panel {
          min-width: 0;
          padding: 25px;
          background: #171a26;
          border: 1px solid #292d3d;
          border-radius: 16px;
          box-sizing: border-box;
        }
        .staff-panel-heading {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
          margin-bottom: 24px;
        }
        .staff-panel-heading h2 {
          margin: 13px 0 8px;
          font-size: 19px;
        }
        .staff-panel-heading p {
          margin: 0;
          color: #a3a9bd;
          font-size: 13px;
          line-height: 1.6;
        }
        .staff-icon {
          display: grid;
          place-items: center;
          width: 38px;
          height: 38px;
          border-radius: 11px;
          background: #302a1d;
          color: #f5b82e;
          font-size: 21px;
        }
        .staff-access-badge {
          flex-shrink: 0;
          padding: 7px 9px;
          border-radius: 7px;
          background: #302a1d;
          color: #f5b82e;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: 1px;
        }
        .staff-form { display: grid; gap: 19px; }
        .staff-form label {
          display: grid;
          gap: 9px;
          color: #e8eaf2;
          font-size: 13px;
          font-weight: 700;
        }
        .staff-form input {
          width: 100%;
          min-width: 0;
          box-sizing: border-box;
          padding: 13px 14px;
          border: 1px solid #383d50;
          border-radius: 9px;
          outline: none;
          background: #10121b;
          color: #f7f8fc;
          font: inherit;
          font-weight: 400;
        }
        .staff-form input:focus {
          border-color: #f5b82e;
          box-shadow: 0 0 0 3px #f5b82e20;
        }
        .staff-form input::placeholder { color: #777f96; }
        .staff-form-note {
          padding: 14px;
          border: 1px solid #383328;
          border-radius: 10px;
          background: #211f1b;
        }
        .staff-form-note strong {
          color: #f5c85e;
          font-size: 12px;
        }
        .staff-form-note p {
          margin: 7px 0 0;
          color: #c3c5cf;
          font-size: 12px;
          line-height: 1.7;
        }
          .staff-form select {
            width: 100%;
            min-width: 0;
            box-sizing: border-box;
            padding: 13px 14px;
            border: 1px solid #383d50;
            border-radius: 9px;
            outline: none;
            background: #10121b;
            color: #f7f8fc;
            font: inherit;
          }

          .staff-form select:focus {
             border-color: #f5b82e;
             box-shadow: 0 0 0 3px #f5b82e20;
           }
        .staff-table select {
         max-width: 190px;
         padding: 7px 9px;
         border: 1px solid #383d50;
         border-radius: 7px;
         background: #10121b;
         color: #f7f8fc;
         font-size: 12px;
       }

        .staff-table select:disabled {
           opacity: 0.6;
           cursor: wait;
         }
        .staff-alert {
          padding: 12px 14px;
          border-radius: 9px;
          font-size: 13px;
          line-height: 1.5;
        }
        .staff-alert-error {
          border: 1px solid #7c343d;
          background: #321b22;
          color: #ffb7c0;
        }
        .staff-alert-success {
          border: 1px solid #286b50;
          background: #152d25;
          color: #a5efc9;
        }
        .staff-primary-button {
          display: inline-flex;
          justify-content: center;
          align-items: center;
          width: 100%;
          padding: 13px 16px;
          border: 0;
          border-radius: 9px;
          background: #f5b82e;
          color: #10121b;
          font-size: 13px;
          font-weight: 800;
          cursor: pointer;
        }
        .staff-primary-button:hover { background: #ffd064; }
        .staff-primary-button:disabled {
          cursor: wait;
          opacity: .65;
        }
        .staff-credentials-panel { border-color: #6a5526; }
        .staff-created-details {
          display: grid;
          gap: 0;
          margin-bottom: 18px;
          border: 1px solid #333747;
          border-radius: 10px;
          overflow: hidden;
        }
        .staff-created-details > div {
          display: grid;
          gap: 6px;
          padding: 13px;
          border-bottom: 1px solid #333747;
        }
        .staff-created-details > div:last-child { border-bottom: 0; }
        .staff-created-details span {
          color: #a3a9bd;
          font-size: 11px;
        }
        .staff-created-details strong {
          overflow-wrap: anywhere;
          font-size: 13px;
        }
        .staff-temp-password {
          color: #f5c85e;
          user-select: all;
        }
        .staff-login-link {
          display: block;
          margin-top: 17px;
          color: #f5b82e;
          text-align: center;
          text-decoration: none;
          font-size: 13px;
        }
        .staff-directory-placeholder {
          display: grid;
          justify-items: center;
          padding: 34px 14px;
          border: 1px dashed #383d50;
          border-radius: 12px;
          text-align: center;
        }
        .staff-directory-placeholder > span {
          color: #f5b82e;
          font-size: 29px;
        }
        .staff-directory-placeholder strong {
          margin-top: 12px;
          font-size: 14px;
        }
        .staff-directory-placeholder p {
          max-width: 290px;
          color: #a3a9bd;
          font-size: 12px;
          line-height: 1.7;
        }
          
       .staff-directory {
         margin-top: 28px;
         padding: 24px;
         border: 1px solid #343434;
         border-radius: 16px;
         background: #171717;
         color: #f5f5f5;
        }

.staff-directory-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
}

.staff-directory-heading h2 {
  margin: 0 0 6px;
}

.staff-directory-heading p,
.staff-table small {
  display: block;
  color: #a7a7a7;
  font-size: 13px;
  margin-top: 5px;
}

.staff-directory button {
  padding: 9px 13px;
  border: 1px solid #b88b2e;
  border-radius: 8px;
  background: transparent;
  color: #f3c969;
  cursor: pointer;
}

.staff-directory button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.staff-table-wrap {
  width: 100%;
  overflow-x: auto;
}

.staff-table {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
}

.staff-table th,
.staff-table td {
  padding: 14px 12px;
  border-bottom: 1px solid #303030;
  vertical-align: top;
  white-space: nowrap;
}

.staff-table th {
  color: #c8a34d;
  font-size: 12px;
  text-transform: uppercase;
}
.staff-role-badge {
  display: inline-block;
  padding: 5px 9px;
  border: 1px solid #5a4a28;
  border-radius: 7px;
  background: #302a1d;
  color: #f5c85e;
  font-size: 11px;
  font-weight: 700;
}
.staff-status {
  display: inline-block;
  padding: 5px 9px;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 700;
}

.staff-status-active {
  color: #9ce6b0;
  background: #173c27;
}

.staff-status-suspended {
  color: #ffcf91;
  background: #49351b;
}

.staff-status-deleted {
  color: #ffaaaa;
  background: #482323;
}

.staff-error {
  color: #ffaaaa;
  margin: 12px 0;
}

        @media (max-width: 900px) {
          .staff-workspace { grid-template-columns: 1fr; }
        }
        @media (max-width: 480px) {
          .staff-panel { padding: 18px; }
          .staff-panel-heading { flex-direction: column; }
        }
      `})]})}},7529:(e,a,t)=>{"use strict";t.d(a,{n:()=>r});let s="https://api.sportyfanz.com".replace(/\/+$/,"")??0;function r(e,a={}){return fetch(function(e){if(/^https?:\/\//i.test(e))return e;let a=e.startsWith("/")?e:`/${e}`;return s?`${s}${a}`:a}(e),{...a,credentials:a.credentials??"include"})}},8551:(e,a,t)=>{Promise.resolve().then(t.bind(t,2443)),Promise.resolve().then(t.bind(t,1028))}},e=>{e.O(0,[8441,3794,7358],()=>e(e.s=8551)),_N_E=e.O()}]);